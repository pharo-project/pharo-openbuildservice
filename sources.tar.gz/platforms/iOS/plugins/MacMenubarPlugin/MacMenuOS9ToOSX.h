//
//  MacMenuOS9ToOSX.h
//  SqueakPureObjc
//
//  Created by John M McIntosh on 09-12-26.
//  Copyright 2009 Corporate Smalltalk Consulting Ltd. All rights reserved.
//
#include "MacMenubarPlugin.h"

