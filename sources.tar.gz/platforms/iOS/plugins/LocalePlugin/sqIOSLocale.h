/*
 *  sqMacLocaleCarbon.h
 *  SqueakLocale
 *
 *  Created by John M McIntosh on 6/9/05.
 *
 */

#include "sqMemoryAccess.h"
#include <locale.h>
#include "sq.h"

