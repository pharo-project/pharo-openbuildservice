/*
 *  sqMacFileBits.c
 *  mpeglibAudioVideo
 *
 *  Created by John M McIntosh on 15/02/06.
 *  Copyright 2006 __MyCompanyName__. All rights reserved.
 *
 */

#include "sqMacFileBits.h"

