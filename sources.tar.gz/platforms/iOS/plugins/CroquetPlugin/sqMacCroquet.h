/*
 *  sqMacCroquet.h
 *  SqueakCroquet
 *
 *  Created by John M McIntosh on 04/04/06.
 *  Copyright 2006 Corporate Smalltalk Consulting Ltd. All rights reserved.
 *  Licenced under the Squeak-L
 *
 */

