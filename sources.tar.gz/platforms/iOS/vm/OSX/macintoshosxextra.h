/*
 *  macintoshosxextra.h
 *  SqueakPureObjc
 *
 *  Created by John M McIntosh on 09-11-14.
 *  Copyright 2009 Corporate Smalltalk Consulting Ltd. All rights reserved.
 *
 */

#include "sq.h"