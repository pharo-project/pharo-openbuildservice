/*
 *  hydramacintoshextra.h
 *  SqueakHydraForCarbon
 *
 *  Created by John M McIntosh on 2/23/08.
 *  Copyright 2008 Corporate Smalltalk Consulting Ltd. All rights reserved.
 *
 */
#include "sq.h"