#include "ieee754names.h"
#include "fdlibm/s_tanh.c"
