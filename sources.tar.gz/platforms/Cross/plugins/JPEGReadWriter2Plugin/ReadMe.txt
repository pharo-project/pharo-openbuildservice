
Project Smarts - C Dynamic Link Library application README
----------------------------------------------------------

Select "Build Normal" on the project's pop-up menu to build the
project target, a DLL file.


