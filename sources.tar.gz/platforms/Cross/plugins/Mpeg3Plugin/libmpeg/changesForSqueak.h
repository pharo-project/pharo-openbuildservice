#include "mpeg3private.h"
int mpeg3_generate_toc_for_Squeak(mpeg3_t *file, int timecode_search, int print_streams, char *buffer, int buffer_size);
void * memoryAllocate(int number,unsigned size);
void memoryFree(void *stuff);
